# Different Ways to Connect — publish guide

This folder contains your phone-friendly autism and communication learning website plus an optional live AI communication coach.

## Publish the website

1. Unzip this folder on a computer if possible.
2. Create/sign in to a Netlify account at https://app.netlify.com/
3. For this project, use a Git-connected Netlify site or Netlify CLI deployment so the `netlify/functions/coach.mjs` server function is deployed too. A simple drag-and-drop of only the HTML file will publish the static pages, but will **not** deploy the live AI function.
4. Add your site files to a GitHub repository, import that repository in Netlify, and deploy. The included `netlify.toml` configures the site and function.
5. In Netlify, open **Site configuration → Environment variables** (menu wording may vary) and add:
   - `OPENAI_API_KEY` = your secret OpenAI API key
   - Optional: `OPENAI_MODEL` = `gpt-4.1-mini`
6. Trigger a new deploy after setting the variables. Test the coach on the published website.

## Important about the AI coach

- You need your own OpenAI API account and API key; API usage may cost money.
- Keep `OPENAI_API_KEY` only in Netlify's server-side environment variables. Never paste it into the HTML, a public repository, or a message.
- The built-in coaching suggestions remain available if the live AI service is not configured.
- This demo does not include user accounts, moderation dashboards, usage limits per person, or a full privacy/legal policy. Before public launch, add suitable privacy information and consider abuse/rate limits to protect against unexpected API costs.
- The diary and learning progress use browser local storage. They do not sync between devices and may be lost if browser data is cleared. Do not enter highly sensitive personal information on shared devices.
- The coach is educational support, not a diagnosis, therapy, or emergency service.

## Files

- `index.html` — main website
- `netlify.toml` — Netlify build settings
- `netlify/functions/coach.mjs` — server-side AI endpoint; API key stays on the server
