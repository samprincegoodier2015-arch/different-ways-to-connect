export default async (req) => {
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405, headers: { "content-type": "application/json", "allow": "POST" }
    });
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return new Response(JSON.stringify({ error: "AI coach is not configured." }), {
      status: 503, headers: { "content-type": "application/json" }
    });
  }

  let body;
  try { body = await req.json(); } catch {
    return new Response(JSON.stringify({ error: "Please send a valid message." }), {
      status: 400, headers: { "content-type": "application/json" }
    });
  }

  const message = typeof body.message === "string" ? body.message.trim().slice(0, 2000) : "";
  if (!message) {
    return new Response(JSON.stringify({ error: "Please enter a message." }), {
      status: 400, headers: { "content-type": "application/json" }
    });
  }

  const instructions = `You are a kind, practical communication coach for autistic and non-autistic people. Help the user find clear, respectful wording for everyday conversations, boundaries, misunderstandings, sensory needs, and social situations. Be non-judgmental, concrete, and concise. Do not claim to diagnose autism or infer someone's feelings from facial expressions. Explain that expressions and body language are clues, not proof. Respect different communication styles and avoid telling autistic people they must mask or force eye contact. Offer 2-4 example phrases when useful. If the user describes imminent danger or crisis, encourage contacting trusted people or local emergency/crisis services. Do not request names, addresses, or other identifying details.`;

  try {
    const upstream = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
        instructions,
        input: message,
        max_output_tokens: 500
      })
    });

    const result = await upstream.json();
    if (!upstream.ok) {
      return new Response(JSON.stringify({ error: "The AI service could not respond. Check the server configuration." }), {
        status: 502, headers: { "content-type": "application/json" }
      });
    }

    const reply = (result.output || [])
      .flatMap(item => item.content || [])
      .filter(part => part.type === "output_text")
      .map(part => part.text)
      .join("\n")
      .trim();

    return new Response(JSON.stringify({ reply: reply || "I couldn't create a reply just now. Please try again." }), {
      status: 200,
      headers: { "content-type": "application/json", "cache-control": "no-store" }
    });
  } catch {
    return new Response(JSON.stringify({ error: "The AI service is temporarily unavailable." }), {
      status: 502, headers: { "content-type": "application/json" }
    });
  }
};
